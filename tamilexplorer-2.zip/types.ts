// types.ts
// TypeScript definitions for User, Messages, and Gamification types

export interface User {
  id: string;
  name: string;
  xp: number;
  level: number;
  coins: number;
  streak: number;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  xp: number;
  avatar: string;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  coinReward: number;
  completed: boolean;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export enum ToolMode {
  TRANSLITERATION = 'TRANSLITERATION',
  PROVERB = 'PROVERB',
}