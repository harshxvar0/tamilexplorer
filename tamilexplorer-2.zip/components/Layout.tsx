// components/Layout.tsx
// Main application layout with 3D Navigation Bar and Responsive Menu

import React, { ReactNode } from 'react';
import { Trophy, User as UserIcon, Menu, X, Globe, Sparkles, MessageCircle } from 'lucide-react';
import { User } from '../types';

interface LayoutProps {
  children: ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: User;
}

interface NavButtonProps {
  item: any;
  isActive: boolean;
  onClick: () => void;
  className?: string;
}

// 3D Nav Button Component
const NavButton: React.FC<NavButtonProps> = ({ item, isActive, onClick, className = "" }) => (
  <button
    onClick={onClick}
    className={`
      relative group flex items-center space-x-2 px-4 py-2 rounded-2xl font-bold text-sm transition-all duration-100 ease-out
      border-b-4 active:border-b-0 active:translate-y-1
      ${isActive 
        ? 'bg-gradient-to-b from-amber-400 to-amber-500 border-amber-700 text-amber-950 shadow-amber-200' 
        : 'bg-white border-stone-300 text-stone-500 hover:bg-stone-50 hover:text-stone-700'
      }
      ${className}
    `}
  >
    <div className={`
      relative z-10
      ${isActive ? 'text-amber-900 drop-shadow-sm' : 'text-stone-400 group-hover:text-stone-600'}
    `}>
      {item.icon}
    </div>
    <span className="relative z-10 tracking-tight">{item.label}</span>
  </button>
);

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab, user }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Home', icon: <Sparkles size={20} strokeWidth={2.5} /> },
    { id: 'chat', label: 'Guide', icon: <MessageCircle size={20} strokeWidth={2.5} /> },
    { id: 'tools', label: 'Tools', icon: <Globe size={20} strokeWidth={2.5} /> },
    { id: 'leaderboard', label: 'Ranks', icon: <Trophy size={20} strokeWidth={2.5} /> },
    { id: 'profile', label: 'Me', icon: <UserIcon size={20} strokeWidth={2.5} /> },
  ];

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-stone-900 font-sans flex flex-col selection:bg-amber-200 selection:text-amber-900">
      
      {/* Top Navigation Bar (Fixed 3D Header) */}
      <header className="fixed top-0 inset-x-0 z-50 bg-white border-b-2 border-stone-200 shadow-sm h-20">
        <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
          
          {/* Logo Section */}
          <div 
            className="flex items-center space-x-3 cursor-pointer group active:scale-95 transition-transform" 
            onClick={() => setActiveTab('dashboard')}
          >
            <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-700 rounded-2xl border-b-4 border-red-900 shadow-lg flex items-center justify-center text-white font-bold font-tamil text-2xl group-hover:-translate-y-1 transition-transform duration-300">
              த
            </div>
            <div className="hidden sm:block leading-tight">
              <h1 className="text-xl font-extrabold text-stone-800 tracking-tight">Tamizh Explorer</h1>
              <p className="text-[10px] font-bold text-amber-600 uppercase tracking-widest bg-amber-50 inline-block px-1 rounded-sm border border-amber-100">Gamified Heritage</p>
            </div>
          </div>

          {/* Desktop Navigation (Center) */}
          <nav className="hidden md:flex items-center space-x-3">
            {navItems.map((item) => (
              <NavButton 
                key={item.id} 
                item={item} 
                isActive={activeTab === item.id} 
                onClick={() => setActiveTab(item.id)} 
              />
            ))}
          </nav>

          {/* User Profile & Mobile Menu Toggle (Right) */}
          <div className="flex items-center space-x-4">
            {/* XP Badge (3D Pill) */}
            <div className="hidden sm:flex items-center bg-stone-800 rounded-2xl px-4 py-1.5 border-b-4 border-stone-950 shadow-md transform hover:-translate-y-0.5 transition-transform">
              <div className="w-2.5 h-2.5 rounded-full bg-green-400 mr-2 animate-pulse shadow-[0_0_10px_rgba(74,222,128,0.5)]"></div>
              <span className="text-xs font-bold text-stone-100 tracking-wider">{user.xp.toLocaleString()} XP</span>
            </div>

            {/* Profile Avatar (3D Circle) */}
            <button 
              onClick={() => setActiveTab('profile')}
              className="w-11 h-11 rounded-full bg-gradient-to-b from-amber-300 to-amber-500 border-b-4 border-amber-700 shadow-lg flex items-center justify-center text-amber-900 font-bold hover:brightness-110 active:border-b-0 active:translate-y-1 transition-all"
            >
              {user.name.charAt(0)}
            </button>

            {/* Mobile Menu Button */}
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 text-stone-600 bg-white border-2 border-stone-200 border-b-4 active:border-b-2 rounded-xl active:translate-y-[2px] transition-all"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-stone-900/60 backdrop-blur-sm md:hidden pt-24 pb-safe" onClick={() => setIsMobileMenuOpen(false)}>
          <div className="mx-4 bg-white rounded-3xl shadow-2xl p-4 space-y-3 border-b-8 border-stone-200 animate-in slide-in-from-top-10 duration-300" onClick={e => e.stopPropagation()}>
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center space-x-4 p-4 rounded-2xl font-bold transition-all border-b-4 active:border-b-0 active:translate-y-1 ${
                  activeTab === item.id
                    ? 'bg-amber-100 text-amber-900 border-amber-300'
                    : 'bg-stone-50 text-stone-600 border-stone-200'
                }`}
              >
                <div className={`p-2 rounded-xl ${activeTab === item.id ? 'bg-amber-200' : 'bg-white shadow-sm'}`}>
                  {item.icon}
                </div>
                <span className="text-lg">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 pt-28 pb-12 px-4 md:px-8 max-w-5xl mx-auto w-full">
         {children}
      </main>
      
    </div>
  );
};