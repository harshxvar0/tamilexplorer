// components/Profile.tsx
// User Profile displaying Stats, Progress Bars, and Rewards

import React from 'react';
import { User } from '../types';
import { MapPin, Star, Calendar, Lock, CheckCircle2 } from 'lucide-react';

interface ProfileProps {
  user: User;
}

const StatCard = ({ icon, label, value, colorClass, borderClass, textClass }: any) => (
  <div className={`bg-white p-6 rounded-[2rem] shadow-sm border-b-8 ${borderClass} flex items-center space-x-5 transition-transform hover:-translate-y-1`}>
    <div className={`w-16 h-16 rounded-2xl ${colorClass} flex items-center justify-center shadow-inner`}>
      {icon}
    </div>
    <div>
      <p className="text-stone-400 text-xs font-black uppercase tracking-wider mb-1">{label}</p>
      <h3 className={`text-2xl font-black ${textClass}`}>{value}</h3>
    </div>
  </div>
);

export const Profile: React.FC<ProfileProps> = ({ user }) => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {/* 3D Stats Grid */}
      <div className="grid md:grid-cols-3 gap-6">
        <StatCard 
            icon={<Star size={32} fill="currentColor" />} 
            label="Total Coins" 
            value={user.coins.toLocaleString()}
            colorClass="bg-amber-100 text-amber-500"
            borderClass="border-amber-200"
            textClass="text-stone-800"
        />
        <StatCard 
            icon={<Calendar size={32} />} 
            label="Day Streak" 
            value={`${user.streak} Days`}
            colorClass="bg-red-100 text-red-500"
            borderClass="border-red-200"
            textClass="text-stone-800"
        />
        <StatCard 
            icon={<MapPin size={32} />} 
            label="Quests Done" 
            value="12"
            colorClass="bg-blue-100 text-blue-500"
            borderClass="border-blue-200"
            textClass="text-stone-800"
        />
      </div>

      {/* The Shrinecation Reward - Premium 3D Card */}
      <div className="bg-stone-900 rounded-[2.5rem] overflow-hidden shadow-2xl relative text-white border-b-8 border-black">
        <div className="absolute inset-0 opacity-50 mix-blend-overlay">
            <img 
                src="https://picsum.photos/1200/600?grayscale&blur=2" 
                alt="Temple Background" 
                className="w-full h-full object-cover"
            />
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500 rounded-full filter blur-[80px] opacity-20"></div>

        <div className="relative z-10 p-8 md:p-12">
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
                <div>
                    <span className="text-amber-400 font-black tracking-widest text-xs uppercase mb-2 block">Ultimate Goal</span>
                    <h2 className="text-3xl md:text-5xl font-black mb-4 tracking-tight">Shrinecation Unlock</h2>
                    <p className="text-lg max-w-xl text-stone-300 mb-8 font-medium leading-relaxed">
                        Redeem your Tamizh Coins for a fully sponsored cultural trip to the Great Living Chola Temples.
                    </p>
                </div>
                <div className="bg-amber-500 text-stone-900 px-6 py-3 rounded-2xl font-bold flex items-center space-x-2 border-b-4 border-amber-700 shadow-lg transform rotate-2">
                    <Lock size={20} />
                    <span>Goal: 50,000 Coins</span>
                </div>
            </div>

            <div className="bg-stone-800/50 backdrop-blur-md p-6 rounded-3xl border border-white/10">
                <div className="flex justify-between text-sm text-stone-300 font-bold mb-2">
                    <span>Progress</span>
                    <span>{((user.coins / 50000) * 100).toFixed(1)}%</span>
                </div>
                <div className="w-full bg-stone-700 h-6 rounded-full overflow-hidden shadow-inner">
                    <div 
                        className="h-full bg-gradient-to-r from-amber-600 to-yellow-400 shadow-[0_0_20px_rgba(251,191,36,0.5)] transition-all duration-1000"
                        style={{ width: `${(user.coins / 50000) * 100}%` }}
                    >
                        <div className="w-full h-full opacity-30 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.5)_50%,transparent_75%)] bg-[length:1rem_1rem]"></div>
                    </div>
                </div>
                <div className="mt-2 text-right text-xs text-stone-500 font-mono">
                    {user.coins.toLocaleString()} / 50,000
                </div>
            </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Achievements */}
        <div className="bg-white p-8 rounded-[2rem] shadow-sm border-b-8 border-stone-100">
            <h3 className="font-black text-xl text-stone-800 mb-6 flex items-center">
                <span className="bg-yellow-100 p-2 rounded-lg text-yellow-600 mr-3"><Star size={20} fill="currentColor" /></span>
                Recent Achievements
            </h3>
            <div className="space-y-4">
                <div className="flex items-center space-x-4 p-4 rounded-2xl bg-stone-50 border border-stone-100">
                    <div className="w-12 h-12 bg-white rounded-xl shadow-sm border-b-4 border-stone-200 flex items-center justify-center text-2xl">📜</div>
                    <div>
                        <p className="font-bold text-stone-800">Mastered Thirukkural</p>
                        <p className="text-xs font-bold text-stone-400 uppercase">Chapter 1 Complete</p>
                    </div>
                    <span className="ml-auto text-amber-600 font-black text-sm bg-amber-50 px-2 py-1 rounded">+500 XP</span>
                </div>
                 <div className="flex items-center space-x-4 p-4 rounded-2xl bg-stone-50 border border-stone-100">
                    <div className="w-12 h-12 bg-white rounded-xl shadow-sm border-b-4 border-stone-200 flex items-center justify-center text-2xl">🔥</div>
                    <div>
                        <p className="font-bold text-stone-800">7 Day Streak</p>
                        <p className="text-xs font-bold text-stone-400 uppercase">Consistency King</p>
                    </div>
                    <span className="ml-auto text-amber-600 font-black text-sm bg-amber-50 px-2 py-1 rounded">+200 XP</span>
                </div>
            </div>
        </div>

        {/* Pending Quests */}
         <div className="bg-white p-8 rounded-[2rem] shadow-sm border-b-8 border-stone-100">
            <h3 className="font-black text-xl text-stone-800 mb-6 flex items-center">
                 <span className="bg-stone-100 p-2 rounded-lg text-stone-600 mr-3"><Lock size={20} /></span>
                Next Milestones
            </h3>
             <div className="space-y-4">
                <div className="flex items-center space-x-4 p-4 rounded-2xl border-2 border-dashed border-stone-200 opacity-70">
                    <div className="w-12 h-12 bg-stone-100 rounded-xl flex items-center justify-center text-stone-400">
                        <Lock size={20} />
                    </div>
                    <div>
                        <p className="font-bold text-stone-600">Silappathikaram Intro</p>
                        <p className="text-xs font-bold text-stone-400 uppercase">Unlocks at Level 6</p>
                    </div>
                </div>
                <div className="flex items-center space-x-4 p-4 rounded-2xl border-2 border-dashed border-stone-200 opacity-70">
                    <div className="w-12 h-12 bg-stone-100 rounded-xl flex items-center justify-center text-stone-400">
                        <Lock size={20} />
                    </div>
                    <div>
                        <p className="font-bold text-stone-600">Advanced Grammar</p>
                        <p className="text-xs font-bold text-stone-400 uppercase">Unlocks at Level 8</p>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};