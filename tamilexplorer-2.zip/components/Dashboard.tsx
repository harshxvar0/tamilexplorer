// components/Dashboard.tsx
// Home Dashboard containing Welcome Banner, Daily Stats, and Feature Links

import React from 'react';
import { User } from '../types';
import { PlayCircle, Award, ChevronRight, Book, Flame, Star } from 'lucide-react';

interface DashboardProps {
    user: User;
    setTab: (tab: string) => void;
}

const Icon3D: React.FC<{ children: React.ReactNode; colorClass: string; shadowClass: string }> = ({ children, colorClass, shadowClass }) => (
    <div className={`w-14 h-14 rounded-2xl ${colorClass} ${shadowClass} border-b-4 flex items-center justify-center shadow-lg transform transition-transform hover:-translate-y-1`}>
        {children}
    </div>
);

export const Dashboard: React.FC<DashboardProps> = ({ user, setTab }) => {
    return (
        <div className="space-y-8 animate-in fade-in duration-500">
            {/* 3D Welcome Banner */}
            <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-r from-red-700 to-red-900 text-white p-8 md:p-10 shadow-xl border-b-8 border-red-950">
                <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500 rounded-full mix-blend-overlay filter blur-[60px] opacity-30 -mr-20 -mt-20"></div>
                <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-600 rounded-full mix-blend-overlay filter blur-[50px] opacity-20 -ml-10 -mb-10"></div>
                
                <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                    <div>
                        <h1 className="text-4xl font-black mb-2 tracking-tight drop-shadow-md">Vanakkam, {user.name}! 🙏</h1>
                        <p className="text-red-100 text-lg font-medium max-w-xl leading-relaxed">
                            Your heritage is waiting. You're on a <span className="text-amber-300 font-bold">{user.streak} day streak</span>!
                        </p>
                    </div>
                    <button 
                        onClick={() => setTab('chat')}
                        className="group bg-gradient-to-b from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-amber-950 font-black py-4 px-8 rounded-2xl border-b-[6px] border-amber-700 active:border-b-0 active:translate-y-1.5 transition-all shadow-xl flex items-center gap-3 text-lg"
                    >
                        <PlayCircle size={28} className="group-hover:scale-110 transition-transform" />
                        Start Daily Quest
                    </button>
                </div>
            </div>

            {/* Daily Word & Progress - 3D Cards */}
            <div className="grid md:grid-cols-2 gap-8">
                {/* Word of Day */}
                <div className="bg-white p-8 rounded-[2rem] shadow-[0_10px_40px_-10px_rgba(0,0,0,0.08)] border-2 border-stone-100 relative overflow-hidden group hover:border-amber-200 transition-colors">
                    <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-green-400 to-emerald-500"></div>
                    <div className="flex justify-between items-start mb-6">
                        <div className="flex items-center gap-3">
                            <Icon3D colorClass="bg-emerald-100 text-emerald-600" shadowClass="border-emerald-200">
                                <Book size={28} strokeWidth={2.5} />
                            </Icon3D>
                            <h3 className="font-bold text-stone-500 uppercase text-xs tracking-widest">Word of the Day</h3>
                        </div>
                        <span className="px-3 py-1.5 bg-emerald-100 text-emerald-800 rounded-lg text-xs font-black border-b-2 border-emerald-200">EASY</span>
                    </div>
                    
                    <div className="text-center py-2 bg-stone-50 rounded-2xl border border-stone-100 mb-4 group-hover:bg-amber-50/50 transition-colors">
                        <h2 className="text-5xl font-extrabold text-stone-800 font-tamil mb-3 drop-shadow-sm mt-2">அறம் (Aram)</h2>
                        <p className="text-xl text-stone-600 font-bold mb-1">Virtue / Righteousness</p>
                        <p className="text-sm text-stone-400 italic font-medium">"Fundamental to Thirukkural"</p>
                    </div>
                </div>
                
                {/* Progress Stats */}
                <div className="bg-white p-8 rounded-[2rem] shadow-[0_10px_40px_-10px_rgba(0,0,0,0.08)] border-2 border-stone-100 relative hover:border-blue-200 transition-colors">
                    <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-400 to-indigo-500"></div>
                     <div className="flex justify-between items-start mb-6">
                        <div className="flex items-center gap-3">
                            <Icon3D colorClass="bg-blue-100 text-blue-600" shadowClass="border-blue-200">
                                <Flame size={28} strokeWidth={2.5} />
                            </Icon3D>
                             <h3 className="font-bold text-stone-500 uppercase text-xs tracking-widest">Level Progress</h3>
                        </div>
                    </div>
                    
                    <div className="space-y-6">
                        <div>
                            <div className="flex justify-between text-sm mb-2 font-bold">
                                <span className="text-stone-700">Level {user.level}</span>
                                <span className="text-stone-400">{user.xp} / 6000 XP</span>
                            </div>
                            <div className="h-5 bg-stone-100 rounded-full overflow-hidden border border-stone-200 p-1">
                                <div className="h-full w-[80%] bg-gradient-to-r from-red-500 to-orange-500 rounded-full shadow-sm"></div>
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="bg-amber-50 p-4 rounded-2xl border-b-4 border-amber-200 flex flex-col items-center justify-center min-h-[100px]">
                                <span className="text-3xl font-black text-amber-700 drop-shadow-sm">{user.coins}</span>
                                <span className="text-xs text-amber-600/70 font-bold uppercase tracking-wider mt-1">Tamizh Coins</span>
                            </div>
                             <div className="bg-indigo-50 p-4 rounded-2xl border-b-4 border-indigo-200 flex flex-col items-center justify-center min-h-[100px]">
                                <span className="text-3xl font-black text-indigo-700 drop-shadow-sm">#6</span>
                                <span className="text-xs text-indigo-600/70 font-bold uppercase tracking-wider mt-1">Global Rank</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Featured Modules */}
            <div>
                <div className="flex justify-between items-center mb-6 px-2">
                    <h2 className="text-2xl font-extrabold text-stone-800 tracking-tight">Explore Heritage</h2>
                    <button className="text-red-700 font-bold text-sm flex items-center hover:bg-red-50 px-3 py-1 rounded-lg transition-colors">
                        View All <ChevronRight size={18} className="ml-1" />
                    </button>
                </div>
                <div className="grid md:grid-cols-3 gap-6">
                    {/* Card 1 */}
                    <div className="group cursor-pointer bg-white rounded-[2rem] shadow-lg border-b-8 border-stone-200 hover:border-amber-400 active:border-b-0 active:translate-y-2 transition-all duration-200 overflow-hidden">
                        <div className="h-36 bg-stone-200 relative overflow-hidden">
                             <img src="https://picsum.photos/400/200?random=1" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="Literature" />
                             <div className="absolute top-3 right-3 bg-white/90 backdrop-blur text-stone-800 text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm">History</div>
                        </div>
                        <div className="p-6">
                            <h3 className="font-bold text-xl text-stone-800 mb-2">The Chola Dynasty</h3>
                            <p className="text-sm text-stone-500 mb-4 font-medium leading-relaxed">Learn about the maritime empire that spanned SE Asia.</p>
                            <div className="flex items-center text-amber-600 text-xs font-black bg-amber-50 w-fit px-3 py-1.5 rounded-lg">
                                <Award size={16} className="mr-1.5" /> 500 XP REWARD
                            </div>
                        </div>
                    </div>

                     {/* Card 2 */}
                    <div 
                        onClick={() => setTab('tools')}
                        className="group cursor-pointer bg-white rounded-[2rem] shadow-lg border-b-8 border-stone-200 hover:border-red-400 active:border-b-0 active:translate-y-2 transition-all duration-200 overflow-hidden"
                    >
                        <div className="h-36 bg-stone-200 relative overflow-hidden">
                             <img src="https://picsum.photos/400/200?random=2" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="Language" />
                             <div className="absolute top-3 right-3 bg-white/90 backdrop-blur text-stone-800 text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm">Tools</div>
                        </div>
                        <div className="p-6">
                            <h3 className="font-bold text-xl text-stone-800 mb-2">Proverb Explorer</h3>
                            <p className="text-sm text-stone-500 mb-4 font-medium leading-relaxed">Decode the hidden meanings in 2000-year-old sayings.</p>
                             <div className="flex items-center text-purple-600 text-xs font-black bg-purple-50 w-fit px-3 py-1.5 rounded-lg">
                                <Star size={16} className="mr-1.5" /> AI POWERED
                            </div>
                        </div>
                    </div>

                     {/* Card 3 */}
                    <div className="group cursor-not-allowed bg-stone-100 rounded-[2rem] border-b-8 border-stone-200 opacity-70 grayscale hover:grayscale-0 transition-all">
                         <div className="h-36 bg-stone-200 relative flex items-center justify-center border-b border-stone-200">
                            <span className="text-stone-400 font-black tracking-widest text-lg bg-stone-100 px-4 py-2 rounded-xl border border-stone-300 transform -rotate-3">COMING SOON</span>
                        </div>
                        <div className="p-6">
                            <h3 className="font-bold text-xl text-stone-500 mb-2">Sangam Literature</h3>
                            <p className="text-sm text-stone-400 mb-3 font-medium">Advanced poetry analysis for scholars.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};