// components/Tools.tsx
// Interactive Tools for Transliteration and Proverb Explanation

import React, { useState } from 'react';
import { ArrowRightLeft, BookOpen, Search, Loader2, Sparkles } from 'lucide-react';
import { ToolMode } from '../types';
import { explainProverb, transliterateText } from '../services/geminiService';

export const Tools: React.FC = () => {
  const [mode, setMode] = useState<ToolMode>(ToolMode.PROVERB);
  
  // Transliteration State
  const [transInput, setTransInput] = useState('');
  const [transOutput, setTransOutput] = useState('');
  const [sourceLang, setSourceLang] = useState('English');
  const [targetLang, setTargetLang] = useState('Tamil');
  const [isTransLoading, setIsTransLoading] = useState(false);

  // Proverb State
  const [proverbQuery, setProverbQuery] = useState('');
  const [proverbResult, setProverbResult] = useState<{ tamil: string; explanation: string; context: string } | null>(null);
  const [isProvLoading, setIsProvLoading] = useState(false);

  const handleTransliterate = async () => {
    if (!transInput.trim()) return;
    setIsTransLoading(true);
    try {
      const result = await transliterateText(transInput, sourceLang, targetLang);
      setTransOutput(result);
    } finally {
      setIsTransLoading(false);
    }
  };

  const handleProverbSearch = async () => {
    if (!proverbQuery.trim()) return;
    setIsProvLoading(true);
    try {
      const result = await explainProverb(proverbQuery);
      setProverbResult(result);
    } finally {
      setIsProvLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {/* 3D Toggle Switcher */}
      <div className="grid grid-cols-2 gap-4 md:gap-8">
        <button
          onClick={() => setMode(ToolMode.PROVERB)}
          className={`
            relative p-6 rounded-[2rem] flex flex-col items-center justify-center space-y-3 transition-all duration-200 border-b-8
            ${mode === ToolMode.PROVERB 
              ? 'bg-gradient-to-br from-red-600 to-red-700 text-white border-red-900 translate-y-2 shadow-inner' 
              : 'bg-white text-stone-500 border-stone-200 hover:border-red-200 hover:text-red-600 shadow-xl active:translate-y-2 active:border-b-0 active:shadow-none'
            }
          `}
        >
          <div className={`p-4 rounded-2xl ${mode === ToolMode.PROVERB ? 'bg-red-800 text-white' : 'bg-stone-100'}`}>
            <BookOpen size={36} strokeWidth={2.5} />
          </div>
          <span className="font-extrabold text-lg">Wisdom & Proverbs</span>
        </button>

        <button
          onClick={() => setMode(ToolMode.TRANSLITERATION)}
          className={`
            relative p-6 rounded-[2rem] flex flex-col items-center justify-center space-y-3 transition-all duration-200 border-b-8
            ${mode === ToolMode.TRANSLITERATION
              ? 'bg-gradient-to-br from-amber-500 to-amber-600 text-white border-amber-800 translate-y-2 shadow-inner' 
              : 'bg-white text-stone-500 border-stone-200 hover:border-amber-200 hover:text-amber-600 shadow-xl active:translate-y-2 active:border-b-0 active:shadow-none'
            }
          `}
        >
          <div className={`p-4 rounded-2xl ${mode === ToolMode.TRANSLITERATION ? 'bg-amber-700 text-white' : 'bg-stone-100'}`}>
            <ArrowRightLeft size={36} strokeWidth={2.5} />
          </div>
          <span className="font-extrabold text-lg">Transliteration</span>
        </button>
      </div>

      {/* Main Content Card - 3D Container */}
      <div className="bg-white p-8 rounded-[2.5rem] shadow-[0_20px_50px_-12px_rgba(0,0,0,0.1)] border-b-8 border-stone-200/80">
        
        {mode === ToolMode.TRANSLITERATION && (
          <div className="animate-in slide-in-from-bottom-4 fade-in">
            <h3 className="text-2xl font-black text-stone-800 mb-8 flex items-center">
              <span className="bg-amber-100 p-2 rounded-xl mr-3 text-amber-600"><ArrowRightLeft size={24} /></span>
              Script Converter
            </h3>
            
            <div className="flex flex-col md:flex-row gap-4 mb-8 bg-stone-50 p-4 rounded-3xl border border-stone-200">
              <select 
                value={sourceLang}
                onChange={(e) => setSourceLang(e.target.value)}
                className="flex-1 p-4 border-b-4 border-stone-200 rounded-2xl bg-white font-bold text-stone-700 focus:border-amber-500 outline-none transition-colors cursor-pointer"
              >
                <option value="English">English (Phonetic)</option>
                <option value="Tamil">Tamil Script</option>
                <option value="Hindi">Hindi</option>
              </select>
              <div className="flex items-center justify-center text-stone-400 font-bold">TO</div>
              <select 
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value)}
                className="flex-1 p-4 border-b-4 border-stone-200 rounded-2xl bg-white font-bold text-stone-700 focus:border-amber-500 outline-none transition-colors cursor-pointer"
              >
                <option value="Tamil">Tamil Script</option>
                <option value="English">English</option>
                <option value="Hindi">Hindi</option>
              </select>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <label className="text-xs font-black text-stone-400 uppercase tracking-widest pl-2">Input Text</label>
                <textarea
                  value={transInput}
                  onChange={(e) => setTransInput(e.target.value)}
                  className="w-full h-48 p-6 border-2 border-stone-200 border-b-4 rounded-3xl bg-stone-50 focus:bg-white focus:border-amber-400 focus:ring-4 focus:ring-amber-100 outline-none resize-none transition-all font-medium text-lg placeholder-stone-400"
                  placeholder="Type here..."
                />
              </div>
              <div className="space-y-3">
                <label className="text-xs font-black text-stone-400 uppercase tracking-widest pl-2">Result</label>
                <div className="w-full h-48 p-6 border-2 border-stone-200 border-b-4 rounded-3xl bg-gradient-to-br from-amber-50 to-orange-50 text-stone-800 font-tamil text-xl leading-relaxed overflow-y-auto shadow-inner">
                  {isTransLoading ? (
                    <div className="h-full flex flex-col items-center justify-center text-amber-500 space-y-2">
                      <Loader2 className="animate-spin" size={32} /> 
                      <span className="font-bold text-sm">Converting magic...</span>
                    </div>
                  ) : (
                    transOutput || <span className="text-stone-300 italic">Translation appears here</span>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-8 flex justify-end">
              <button
                onClick={handleTransliterate}
                disabled={isTransLoading || !transInput}
                className="px-8 py-4 bg-stone-900 hover:bg-stone-800 text-white font-black rounded-2xl border-b-4 border-stone-950 active:border-b-0 active:translate-y-1 transition-all disabled:opacity-50 disabled:active:translate-y-0 shadow-lg flex items-center gap-2"
              >
                <Sparkles size={20} className="text-amber-400" />
                Convert Now
              </button>
            </div>
          </div>
        )}

        {mode === ToolMode.PROVERB && (
          <div className="animate-in slide-in-from-bottom-4 fade-in">
            <h3 className="text-2xl font-black text-stone-800 mb-8 flex items-center">
              <span className="bg-red-100 p-2 rounded-xl mr-3 text-red-600"><BookOpen size={24} /></span>
              Proverb Explorer
            </h3>

            <div className="flex gap-4 mb-10">
              <div className="flex-1 relative">
                <input
                  type="text"
                  value={proverbQuery}
                  onChange={(e) => setProverbQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleProverbSearch()}
                  placeholder="Enter topic (e.g. 'Friendship', 'Rain')..."
                  className="w-full p-4 pl-6 border-2 border-stone-200 border-b-4 rounded-2xl focus:outline-none focus:border-red-400 focus:ring-4 focus:ring-red-100 transition-all font-bold text-lg"
                />
              </div>
              <button
                onClick={handleProverbSearch}
                disabled={isProvLoading}
                className="px-6 bg-red-600 text-white rounded-2xl border-b-4 border-red-800 hover:bg-red-500 active:border-b-0 active:translate-y-1 font-bold shadow-lg transition-all"
              >
                {isProvLoading ? <Loader2 className="animate-spin" /> : <Search strokeWidth={3} />}
              </button>
            </div>

            {proverbResult && (
              <div className="bg-stone-50 rounded-[2rem] p-8 border-2 border-stone-200 animate-in fade-in zoom-in-95 duration-300 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-32 bg-amber-200 rounded-full blur-[100px] opacity-20 -mr-20 -mt-20 pointer-events-none"></div>
                
                <div className="mb-6 relative z-10">
                  <span className="text-[10px] font-black text-amber-600 uppercase tracking-widest bg-amber-100 px-2 py-1 rounded-md">Tamil Wisdom</span>
                  <h2 className="text-3xl md:text-4xl font-extrabold text-stone-800 font-tamil mt-4 mb-6 leading-relaxed drop-shadow-sm">
                    {proverbResult.tamil}
                  </h2>
                </div>
                <div className="grid md:grid-cols-2 gap-6 relative z-10">
                  <div className="bg-white p-6 rounded-2xl shadow-sm border-b-4 border-stone-100">
                    <h4 className="font-bold text-stone-400 uppercase text-xs tracking-wider mb-3">Meaning</h4>
                    <p className="text-stone-700 text-lg leading-relaxed font-medium">{proverbResult.explanation}</p>
                  </div>
                  <div className="bg-amber-50 p-6 rounded-2xl border-b-4 border-amber-100">
                    <h4 className="font-bold text-amber-700/60 uppercase text-xs tracking-wider mb-3">Context</h4>
                    <p className="text-amber-900 leading-relaxed italic font-medium">"{proverbResult.context}"</p>
                  </div>
                </div>
              </div>
            )}

            {!proverbResult && !isProvLoading && (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-stone-100 rounded-full mx-auto mb-6 flex items-center justify-center text-stone-300">
                    <Search size={40} />
                </div>
                <p className="text-stone-400 font-medium text-lg">Search for a topic to discover ancient wisdom.</p>
                <div className="flex flex-wrap justify-center gap-3 mt-6">
                  {['Education', 'Farming', 'Love', 'Time', 'Wealth'].map(tag => (
                    <button 
                      key={tag}
                      onClick={() => { setProverbQuery(tag); setTimeout(handleProverbSearch, 100); }}
                      className="px-4 py-2 bg-white border-b-2 border-stone-200 rounded-xl text-sm font-bold text-stone-600 hover:border-red-300 hover:text-red-600 hover:-translate-y-1 transition-all"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};