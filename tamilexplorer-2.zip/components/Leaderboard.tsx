// components/Leaderboard.tsx
// Global Leaderboard to display user rankings and XP with 3D Medals

import React from 'react';
import { LeaderboardEntry } from '../types';
import { Trophy, Medal, Crown, Star } from 'lucide-react';

export const Leaderboard: React.FC = () => {
  const leaderboardData: LeaderboardEntry[] = [
    { rank: 1, name: "Arun Kumar", xp: 15420, avatar: "A" },
    { rank: 2, name: "Priya S.", xp: 14200, avatar: "P" },
    { rank: 3, name: "Senthil R.", xp: 12850, avatar: "S" },
    { rank: 4, name: "Divya M.", xp: 10500, avatar: "D" },
    { rank: 5, name: "Karthik J.", xp: 9800, avatar: "K" },
    { rank: 6, name: "You", xp: 5200, avatar: "Y" },
    { rank: 7, name: "Meera V.", xp: 4500, avatar: "M" },
  ];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: 
        return <div className="w-10 h-10 bg-yellow-400 rounded-full border-b-4 border-yellow-600 flex items-center justify-center text-yellow-900 shadow-lg"><Crown size={20} fill="currentColor" /></div>;
      case 2: 
        return <div className="w-10 h-10 bg-stone-300 rounded-full border-b-4 border-stone-500 flex items-center justify-center text-stone-700 shadow-lg"><Medal size={20} /></div>;
      case 3: 
        return <div className="w-10 h-10 bg-amber-700 rounded-full border-b-4 border-amber-900 flex items-center justify-center text-amber-100 shadow-lg"><Medal size={20} /></div>;
      default: 
        return <span className="text-stone-400 font-black text-xl w-6 text-center">{rank}</span>;
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      
      {/* 3D Header Card */}
      <div className="bg-gradient-to-r from-red-600 to-red-800 rounded-[2rem] p-8 md:p-10 text-white shadow-2xl border-b-8 border-red-900 relative overflow-hidden flex items-center justify-between">
        <div className="absolute top-0 right-0 p-32 bg-yellow-400 rounded-full blur-[80px] opacity-20 -mr-20 -mt-20"></div>
        
        <div className="relative z-10">
          <div className="flex items-center space-x-2 mb-2 text-red-200 uppercase font-black tracking-widest text-xs">
            <Star size={14} /> <span>Global Rankings</span>
          </div>
          <h2 className="text-4xl font-extrabold mb-3 drop-shadow-sm">Wall of Fame</h2>
          <p className="text-red-100 font-medium text-lg max-w-sm">Compete with Tamizh explorers worldwide for the Shrinecation reward.</p>
        </div>
        <div className="relative z-10 bg-white/10 p-4 rounded-2xl backdrop-blur-sm border border-white/20 hidden sm:block transform rotate-6">
             <Trophy size={64} className="text-yellow-300 drop-shadow-md" />
        </div>
      </div>

      {/* Leaderboard List */}
      <div className="bg-white rounded-[2.5rem] shadow-[0_15px_50px_-10px_rgba(0,0,0,0.1)] border-b-8 border-stone-200 overflow-hidden">
        <div className="p-6 bg-stone-50 border-b-2 border-stone-100 grid grid-cols-12 text-xs font-black text-stone-400 uppercase tracking-widest">
          <div className="col-span-2 text-center">Rank</div>
          <div className="col-span-6 pl-4">Explorer</div>
          <div className="col-span-4 text-right pr-4">XP Earned</div>
        </div>

        <div className="divide-y divide-stone-100">
          {leaderboardData.map((entry) => (
            <div 
              key={entry.rank}
              className={`grid grid-cols-12 items-center p-4 md:p-5 transition-colors group ${
                entry.name === 'You' ? 'bg-amber-50/60' : 'hover:bg-stone-50'
              }`}
            >
              <div className="col-span-2 flex justify-center">
                {getRankIcon(entry.rank)}
              </div>
              
              <div className="col-span-6 flex items-center space-x-4 pl-4">
                <div className={`w-12 h-12 rounded-2xl border-b-4 flex items-center justify-center font-bold text-lg shadow-sm transform group-hover:-translate-y-1 transition-transform ${
                  entry.rank === 1 ? 'bg-yellow-100 border-yellow-300 text-yellow-700' : 
                  entry.rank === 2 ? 'bg-stone-200 border-stone-400 text-stone-600' :
                  entry.rank === 3 ? 'bg-amber-100 border-amber-300 text-amber-800' : 
                  entry.name === 'You' ? 'bg-red-100 border-red-300 text-red-700' : 'bg-stone-100 border-stone-200 text-stone-500'
                }`}>
                  {entry.avatar}
                </div>
                <div>
                    <span className={`font-bold text-base block ${entry.name === 'You' ? 'text-red-800' : 'text-stone-700'}`}>
                    {entry.name}
                    </span>
                    {entry.name === 'You' && <span className="text-[10px] font-bold uppercase text-amber-600 bg-amber-100 px-1.5 py-0.5 rounded-md">It's You!</span>}
                </div>
              </div>
              
              <div className="col-span-4 text-right pr-4">
                <span className="font-mono font-black text-stone-600 text-lg">{entry.xp.toLocaleString()}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};