// components/ChatBot.tsx
// AI-Powered Chat Interface with 3D Styling and Real-time Responses

import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, Loader2, Sparkles } from 'lucide-react';
import { Message } from '../types';
import { chatWithTamilGuide } from '../services/geminiService';

export const ChatBot: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'model',
      text: 'Vanakkam! I am Thiru. I can help you practice Tamil, explore ancient literature, or explain grammar. What shall we discuss today?',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      // Create a formatted history string to give the AI context
      const history = messages.slice(-5).map(m => 
        `${m.role === 'model' ? 'Thiru' : 'User'}: ${m.text}`
      ).join('\n');
      
      const responseText = await chatWithTamilGuide(history, input);

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      console.error(error);
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: "I encountered an error connecting to the service. Please try again.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-160px)] bg-white rounded-[2.5rem] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.1)] border-b-8 border-stone-200 overflow-hidden relative">
      
      {/* 3D Header */}
      <div className="bg-gradient-to-r from-amber-50 to-white p-6 border-b border-stone-100 flex items-center justify-between z-10 relative">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl shadow-lg border-b-4 border-amber-700 flex items-center justify-center text-white transform hover:-translate-y-1 transition-transform">
            <Bot size={32} />
          </div>
          <div>
            <h2 className="font-black text-xl text-stone-800">Thiru Guide</h2>
            <div className="flex items-center space-x-2 mt-1">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              <p className="text-xs font-bold text-stone-500 uppercase tracking-wide">Online • AI Powered</p>
            </div>
          </div>
        </div>
        <div className="bg-amber-100 p-2 rounded-xl text-amber-600 hidden sm:block">
            <Sparkles size={20} />
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#FDFBF7]">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] md:max-w-[70%] p-5 rounded-3xl shadow-sm border-b-4 relative animate-in zoom-in-95 duration-200 ${
                msg.role === 'user'
                  ? 'bg-gradient-to-br from-red-600 to-red-700 text-white border-red-900 rounded-br-none'
                  : 'bg-white text-stone-800 border-stone-200 rounded-bl-none'
              }`}
            >
              <p className="whitespace-pre-wrap leading-relaxed font-medium text-[15px]">{msg.text}</p>
              <span className={`text-[10px] mt-2 block font-bold opacity-70 ${msg.role === 'user' ? 'text-red-100' : 'text-stone-400'}`}>
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white p-4 rounded-3xl rounded-bl-none border-b-4 border-stone-200 shadow-sm flex items-center space-x-3">
              <Loader2 className="animate-spin text-amber-500" size={20} />
              <span className="text-sm font-bold text-stone-500">Thiru is thinking...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* 3D Input Area */}
      <div className="p-4 md:p-6 bg-white border-t border-stone-100">
        <div className="flex items-center space-x-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about Thirukkural, history..."
            className="flex-1 p-4 border-2 border-stone-200 border-b-4 rounded-2xl focus:outline-none focus:border-amber-400 focus:bg-amber-50/30 transition-all font-medium placeholder-stone-400"
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="p-4 bg-stone-900 text-white rounded-2xl border-b-4 border-stone-950 hover:bg-stone-800 active:border-b-0 active:translate-y-1 disabled:opacity-50 disabled:active:translate-y-0 transition-all shadow-xl"
          >
            <Send size={24} />
          </button>
        </div>
      </div>
    </div>
  );
};