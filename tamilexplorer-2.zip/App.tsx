// App.tsx
// Main Application Component managing routing and global user state

import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { ChatBot } from './components/ChatBot';
import { Tools } from './components/Tools';
import { Leaderboard } from './components/Leaderboard';
import { Profile } from './components/Profile';
import { User } from './types';

// Mock Initial User State
const INITIAL_USER: User = {
  id: 'u1',
  name: 'Tamizh Explorer',
  xp: 5200,
  level: 5,
  coins: 2450,
  streak: 5
};

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [user] = useState<User>(INITIAL_USER);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard user={user} setTab={setActiveTab} />;
      case 'chat':
        return <ChatBot />;
      case 'tools':
        return <Tools />;
      case 'leaderboard':
        return <Leaderboard />;
      case 'profile':
        return <Profile user={user} />;
      default:
        return <Dashboard user={user} setTab={setActiveTab} />;
    }
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab} user={user}>
      {renderContent()}
    </Layout>
  );
};

export default App;