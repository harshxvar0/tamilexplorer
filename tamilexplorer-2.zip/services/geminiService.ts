// services/geminiService.ts
// AI Integration Service using Google Gemini API for Chat, Transliteration, and Proverbs

import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Initialize Gemini AI Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = 'gemini-2.5-flash';

export const chatWithTamilGuide = async (history: string, message: string): Promise<string> => {
  try {
    const systemInstruction = `You are 'Thiru', a wise, friendly, and encouraging Tamil cultural guide. 
    Your goal is to help users learn the Tamil language, understand its 2000-year-old history, and appreciate its literature.
    You can speak in English to explain concepts, but encourage the use of Tamil words.
    If the user makes a mistake in Tamil, gently correct them.
    Keep responses concise (under 150 words) unless asked for a story.
    Tone: Respectful, enthusiastic, educational.`;

    // Combine history and current message to provide context to the model
    // This allows the model to understand the flow of conversation
    const fullPrompt = history 
      ? `Previous conversation context:\n${history}\n\nCurrent User Message: ${message}`
      : message;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: fullPrompt,
      config: {
        systemInstruction: systemInstruction,
      }
    });
    
    return response.text || "I apologize, I am having trouble connecting to the wisdom of the ancients right now.";
  } catch (error) {
    console.error("Gemini Chat Error:", error);
    return "I am unable to connect to the server. Please check your API key and network connection.";
  }
};

export const transliterateText = async (text: string, sourceLang: string, targetLang: string): Promise<string> => {
  try {
    const prompt = `Transliterate and translate the following text strictly from ${sourceLang} to ${targetLang}. 
    If the target is Tamil, provide the Tamil Script. 
    If the source is Tamil script, provide the phonetic English or Hindi as requested.
    Only return the result string, no explanations.
    
    Input: "${text}"`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
    });

    return response.text?.trim() || "Transliteration failed.";
  } catch (error) {
    console.error("Transliteration Error:", error);
    return "Error processing request. Please try again.";
  }
};

export const explainProverb = async (query: string): Promise<{ tamil: string; explanation: string; context: string }> => {
  try {
    const prompt = `The user wants to know about this Tamil proverb or topic: "${query}".
    Provide a response in JSON format with the following keys:
    1. "tamil": The proverb in Tamil script (if applicable, otherwise the key phrase).
    2. "explanation": A clear English explanation of the meaning.
    3. "context": A brief cultural or historical context (one sentence).
    
    If the user input is not a proverb, provide a relevant Tamil cultural insight based on the keywords.`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    let text = response.text;
    if (!text) throw new Error("No response text from model");

    // Clean up any Markdown code blocks if the model includes them
    text = text.replace(/^```json\s*/, '').replace(/\s*```$/, '');

    return JSON.parse(text);
  } catch (error) {
    console.error("Proverb Error:", error);
    return {
      tamil: "Search Unavailable",
      explanation: "We could not retrieve information at this moment.",
      context: "Please check your connection and try again."
    };
  }
};